/*
 * SQLeonardo :: java database frontend
 * Copyright (C) 2004 nickyb@users.sourceforge.net
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

package nickyb.sqleonardo.environment.ctrl.explorer;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.Enumeration;

import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.filechooser.FileFilter;
import javax.swing.tree.DefaultMutableTreeNode;

import nickyb.sqleonardo.common.gui.BorderLayoutPanel;
import nickyb.sqleonardo.common.gui.CommandButton;
import nickyb.sqleonardo.common.gui.ListView;
import nickyb.sqleonardo.common.jdbc.ConnectionAssistant;
import nickyb.sqleonardo.common.util.Classpath;
import nickyb.sqleonardo.environment.Application;
import nickyb.sqleonardo.environment.Preferences;

public class ViewDatasources extends ListView
{
	private InstallBar installBar;
	private SideNavigator navigator;
	
	public ViewDatasources(SideNavigator navigator)
	{
		this.navigator = navigator;
		
		addColumn("name");
		addColumn("url");
		addColumn("status");
		
		setComponentSouth(installBar = new InstallBar());
	}
	
	public void list(DefaultMutableTreeNode node)
	{
		UoDriver uoDv = (UoDriver)node.getUserObject();
		installBar.setVisible(uoDv.message != null);
		installBar.message.setText(uoDv.message);
		
		removeAllRows();
		for(Enumeration e = node.children(); e.hasMoreElements();)
		{
			DefaultMutableTreeNode child = (DefaultMutableTreeNode)e.nextElement();
			UoDatasource uoDs = (UoDatasource)child.getUserObject();
			
			Object[] rowdata = new Object[3];
			rowdata[0] = uoDs.name;
			rowdata[1] = uoDs.url;
			rowdata[2] = uoDs.isConnected() ? "connected" : "disconnected";
			
			addRow(rowdata);
		}
	}
	
	private class InstallBar extends BorderLayoutPanel implements ActionListener
	{
		JLabel message;
		
		InstallBar()
		{
			message = new JLabel(Application.resources.getIcon(Application.ICON_EXPLORER_DRIVER_KO));
			setComponentCenter(message);
			setComponentEast(new CommandButton("install",this));
		}
		
		public void actionPerformed(ActionEvent ae)
		{
			String currentDirectory = Preferences.getString("lastDirectory",System.getProperty("user.home"));
			
			JFileChooser fc = new JFileChooser(currentDirectory);
			fc.setFileSelectionMode(JFileChooser.FILES_ONLY);
			fc.setMultiSelectionEnabled(false);
		
			fc.setFileFilter(new FileFilter()
			{
				public boolean accept(File file)
				{
					return file.isDirectory() || file.getName().toLowerCase().endsWith(".jar") || file.getName().toLowerCase().endsWith(".zip");
				}
				public String getDescription()
				{
					return "library files (*.jar, *.zip)";
				}
			});

			if(fc.showOpenDialog(Application.window) == JFileChooser.APPROVE_OPTION)
			{
				Preferences.set("lastDirectory",fc.getCurrentDirectory().toString());
				
				UoDriver uoDv = (UoDriver)ViewDatasources.this.navigator.getSelectionNode().getUserObject();
				try
				{
					String file = fc.getSelectedFile().toString();					
					ConnectionAssistant.declare(file,uoDv.classname,!Classpath.isRuntime(file));
					
					uoDv.library = file;
					uoDv.message = null;
					
					ViewDatasources.this.navigator.reloadSelection();
				}
				catch(Exception e)
				{
					Application.alert(Application.PROGRAM,"Installation failed!");
					uoDv.message = e.getMessage();
				}				
			}
		}
	}
}
