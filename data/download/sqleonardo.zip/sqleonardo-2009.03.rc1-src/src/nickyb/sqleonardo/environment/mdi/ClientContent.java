/*
 * SQLeonardo :: java database frontend
 * Copyright (C) 2004 nickyb@users.sourceforge.net
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

package nickyb.sqleonardo.environment.mdi;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.sql.ResultSetMetaData;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import javax.swing.border.EmptyBorder;
import javax.swing.event.InternalFrameAdapter;
import javax.swing.event.InternalFrameEvent;
import javax.swing.event.InternalFrameListener;

import nickyb.sqleonardo.common.gui.Toolbar;
import nickyb.sqleonardo.environment.Application;
import nickyb.sqleonardo.environment.ctrl.ContentPane;
import nickyb.sqleonardo.environment.ctrl.content.DialogFilters;
import nickyb.sqleonardo.environment.ctrl.content.DialogFindReplace;
import nickyb.sqleonardo.environment.ctrl.content.DialogPreview;
import nickyb.sqleonardo.environment.ctrl.content.DialogStream;
import nickyb.sqleonardo.environment.ctrl.content.DialogUpdateCriteria;
import nickyb.sqleonardo.environment.ctrl.content.UpdateModel;
import nickyb.sqleonardo.environment.ctrl.define.TableMetaData;
import nickyb.sqleonardo.querybuilder.QueryModel;

public class ClientContent extends MDIClient
{
	public static final String DEFAULT_TITLE = "content";	
	
	private ContentPane control;
	private JMenuItem[] m_actions;
	private Toolbar toolbar;
	
	private DialogFindReplace dlg;
	
	public ClientContent(TableMetaData tmd, boolean retrieve)
	{
		this(tmd.getHandlerKey(),tmd.createQueryModel(),tmd.createUpdateModel(),retrieve);
		
		if(!retrieve)
		{
			for(int i=0; i<tmd.getColumns().size(); i++)
			{
				String name = tmd.getColumnProperty(i,TableMetaData.IDX_COL_COLUMN_NAME);
				String type = tmd.getColumnProperty(i,TableMetaData.IDX_COL_DATA_TYPE);
				
				control.getView().addColumn(name,Integer.valueOf(type).intValue());
			}
			
			control.getView().onTableChanged(false);
			
			for(int i=0; i<tmd.getColumns().size(); i++)
			{
				String t = tmd.getColumnProperty(i,TableMetaData.IDX_COL_COLUMN_NAME) + " : " + tmd.getColumnProperty(i,TableMetaData.IDX_COL_TYPE_NAME);
				t = t + (Integer.valueOf(tmd.getColumnProperty(i,TableMetaData.IDX_COL_NULLABLE)).intValue() == ResultSetMetaData.columnNullable ? "(null)" : "(not null)");
				control.getView().setToolTipText(i,t);
			}			
			
			control.doRefreshStatus();
		}
	}
	
	public ClientContent(String keycah, QueryModel qmodel, UpdateModel umodel)
	{
		this(keycah,qmodel,umodel,true);
	}
	
	private ClientContent(String keycah, QueryModel qmodel, UpdateModel umodel, boolean retrieve)
	{
		super(DEFAULT_TITLE);
		setMaximizable(true);
		setResizable(true);
		
		setComponentCenter(control = new ContentPane(keycah,qmodel,umodel));
		control.setBorder(new EmptyBorder(2,2,2,2));
		
		setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		InternalFrameListener ifl = new InternalFrameAdapter()
		{
			public void internalFrameDeactivated(InternalFrameEvent e)
			{
				if(ClientContent.this.dlg!=null)
					ClientContent.this.dlg.setVisible(false);
			}

			public void internalFrameClosing(InternalFrameEvent evt)
			{
				if(!ClientContent.this.control.isBusy()
				&& !ClientContent.this.control.isReadOnly()
				&& ClientContent.this.control.getView().getChanges().count() > 0)
				{
					int option = JOptionPane.showConfirmDialog(Application.window,"do you want save changes?",Application.PROGRAM,JOptionPane.YES_NO_CANCEL_OPTION);
					
					if(option == JOptionPane.YES_OPTION)
						ClientContent.this.control.getActionMap().get("changes-save").actionPerformed(null);
					else if (option != JOptionPane.NO_OPTION)
						return;
				}
				
				ClientContent.this.control.doStop();
				ClientContent.this.dispose();
			}
		};
		addInternalFrameListener(ifl);
		
		createToolbar();
		initMenuActions();
		
		if(retrieve)
			control.doRetrieve();
		else
			control.doStop();
	}
    
	private void createToolbar()
	{
		toolbar = new Toolbar(Toolbar.HORIZONTAL);
		toolbar.add(control.getActionMap().get("changes-save"));
		toolbar.add(control.getActionMap().get("task-stop"));
		toolbar.addSeparator();
		toolbar.add(control.getActionMap().get("record-insert"));
		toolbar.add(control.getActionMap().get("record-delete"));
		toolbar.addSeparator();
		toolbar.add(new ActionShowFilter());
		toolbar.add(new ActionShowFindReplace());
        
		setComponentEast(toolbar);
	}

	private void initMenuActions()
	{
		Action a = control.getActionMap().get("task-go");
		a.putValue(Action.ACCELERATOR_KEY,KeyStroke.getKeyStroke(KeyEvent.VK_F5,0));
		
		m_actions = new JMenuItem[]
		{
			MDIMenubar.createItem(new ActionShowUpdateCriteria()),
			MDIMenubar.createItem(new ActionShowChanges()),
			null,
			MDIMenubar.createItem(new ActionShowExport()),
			MDIMenubar.createItem(new ActionShowImport()),
			null,
			MDIMenubar.createItem(control.getActionMap().get("task-go"))
		};
	}
	
	public final void dispose()
	{
		if(ClientContent.this.dlg!=null) dlg.dispose();
		super.dispose();
	}
	
	public final ContentPane getControl()
	{
		return control;
	}	
	
	protected String getMessage()
	{
		int rows = control.getView().getRowCount();
		if(rows == 0) return null;
		
		String first = control.getView().getValueAt(0,0).toString();
		String last = control.getView().getValueAt(rows-1,0).toString();
		
		return "block " + control.getView().getBlock() + " of " + control.getView().getBlockCount() + " - record(s) " + first + " to " + last + " of " + control.getView().getFlatRowCount();
	}

	public JMenuItem[] getMenuActions()
	{
		return m_actions;
	}

	public Toolbar getSubToolbar()
	{
		return toolbar;
	}
    
	protected void setPreferences()
	{
	}

	private class ActionShowUpdateCriteria extends AbstractAction
	{
		ActionShowUpdateCriteria()
		{
			super("update criteria...");			
		}

		public void actionPerformed(ActionEvent ae)
		{
			if(ClientContent.this.control.isBusy()) return;
			new DialogUpdateCriteria(ClientContent.this.control).setVisible(true);
		}
	}
		
	private class ActionShowChanges extends AbstractAction
	{
		ActionShowChanges()
		{
			super("show changes...");
		}

		public void actionPerformed(ActionEvent ae)
		{
			if(ClientContent.this.control.isBusy()) return;
			
			if(ClientContent.this.control.getUpdateModel() !=null && ClientContent.this.control.getUpdateModel().getRowIdentifierCount() > 0)
			{
				new DialogPreview(ClientContent.this.control).setVisible(true);
			}
			else
			{
				Application.alert(Application.PROGRAM,"No update criteria defined!");
			}			
		}
	}	

	private class ActionShowImport extends AbstractAction
	{
		ActionShowImport()
		{
			this.putValue(NAME, "import data...");
		}

		public void actionPerformed(ActionEvent ae)
		{
			if(ClientContent.this.control.isBusy()) return;
			DialogStream.showImport(ClientContent.this.control);
		}
	}
		
	private class ActionShowExport extends AbstractAction
	{
		ActionShowExport()
		{
			this.putValue(NAME, "export data...");
		}

		public void actionPerformed(ActionEvent ae)
		{
			if(ClientContent.this.control.isBusy()) return;
			DialogStream.showExport(ClientContent.this.control);
		}
	}
	
	private class ActionShowFilter extends AbstractAction
	{
		ActionShowFilter()
		{
			this.putValue(SMALL_ICON, Application.resources.getIcon(Application.ICON_FILTER));
			this.putValue(SHORT_DESCRIPTION, "filter");
			this.putValue(NAME, "filter...");
		}

		public void actionPerformed(ActionEvent ae)
		{
			if(ClientContent.this.control.isBusy()) return;
			new DialogFilters(ClientContent.this.control).setVisible(true);
		}
	}	
	
	private class ActionShowFindReplace extends AbstractAction
	{
		ActionShowFindReplace()
		{
			this.putValue(SMALL_ICON, Application.resources.getIcon(Application.ICON_FIND));
			this.putValue(SHORT_DESCRIPTION, "find/replace...");
			this.putValue(NAME, "find/replace...");			
		}
		
		public void actionPerformed(ActionEvent ae)
		{
			if(ClientContent.this.control.isBusy()) return;
			if(ClientContent.this.dlg == null)
				ClientContent.this.dlg = new DialogFindReplace(ClientContent.this.control);
			dlg.setVisible(true);
		}
	}
}
