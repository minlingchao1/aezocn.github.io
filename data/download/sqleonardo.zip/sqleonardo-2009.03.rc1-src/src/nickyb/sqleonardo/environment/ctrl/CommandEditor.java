/*
 * SQLeonardo :: java database frontend
 * Copyright (C) 2004 nickyb@users.sourceforge.net
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

package nickyb.sqleonardo.environment.ctrl;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.event.ActionEvent;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.KeyEvent;
import java.util.StringTokenizer;

import javax.swing.AbstractAction;
import javax.swing.JSplitPane;
import javax.swing.KeyStroke;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultStyledDocument;
import javax.swing.text.MutableAttributeSet;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;

import nickyb.sqleonardo.common.gui.BorderLayoutPanel;
import nickyb.sqleonardo.common.gui.TextView;
import nickyb.sqleonardo.environment.Application;
import nickyb.sqleonardo.environment.ctrl.editor.SQLStyledDocument;
import nickyb.sqleonardo.environment.ctrl.editor.Task;
import nickyb.sqleonardo.environment.ctrl.editor._TaskSource;
import nickyb.sqleonardo.environment.ctrl.editor._TaskTarget;
import nickyb.sqleonardo.environment.mdi.ClientCommandEditor;

public class CommandEditor extends BorderLayoutPanel implements _TaskTarget
{
	private boolean stopped;
	
	private Thread queryThread;
	
	private TextView request;
	private TextView response;
	
	protected MutableAttributeSet errorAttributSet;
	protected MutableAttributeSet keycahAttributSet;
	
	public CommandEditor()
	{
		JSplitPane split = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
		split.setTopComponent(request = new TextView(new SQLStyledDocument()));
		split.setBottomComponent(response = new TextView(new DefaultStyledDocument()));
		split.setOneTouchExpandable(true);

		response.setTabSize(4);
		response.setEditable(false);

		setComponentCenter(split);

		request.getViewActionMap().put("stop-task"	,new ActionStopTask());
		request.getViewActionMap().put("start-task",new ActionStartTask());
		request.getViewInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER,KeyEvent.CTRL_MASK),"start-task");
		
		getActionMap().setParent(request.getViewActionMap());
		
		this.addComponentListener(new ComponentAdapter()
		{
			public void componentResized(ComponentEvent evt)
			{
				JSplitPane split = (JSplitPane)CommandEditor.this.getComponent(0);
				split.setDividerLocation(0.5);
				split.validate();
			} 
		});
		
		errorAttributSet = new SimpleAttributeSet();
		StyleConstants.setForeground(errorAttributSet, Color.red);
		
		keycahAttributSet = new SimpleAttributeSet();
		StyleConstants.setForeground(keycahAttributSet, new Color(0,128,0));
		StyleConstants.setBold(keycahAttributSet,true);
	}
	
	public void append(String text)
	{
		request.append(text);
	}
	
	public void clearResponse()
	{
		response.setText(null);
		request.requestFocus();
	}
	
	public TextView getRequestArea()
	{
		return request;
	}

	public TextView getResponseArea()
	{
		return request;
	}

	public String getSelectedText()
	{
		return request.getSelectedText();
	}
	
	public SQLStyledDocument getDocument()
	{
		return (SQLStyledDocument)request.getDocument();
	}
	
	public void setDocument(SQLStyledDocument doc)
	{
		this.request.setDocument(doc);
		this.request.setCaretPosition(0);
		this.request.requestFocus();
	}
	
//	/////////////////////////////////////////////////////////////////////////////
//	Actions
//	/////////////////////////////////////////////////////////////////////////////
	private class ActionStartTask extends AbstractAction implements Runnable
	{
		ActionStartTask()
		{
			this.putValue(SMALL_ICON, Application.resources.getIcon(Application.ICON_EDITOR_RUN));
			this.putValue(SHORT_DESCRIPTION, "launch");
		}

		public void actionPerformed(ActionEvent ae)
		{
			CommandEditor.this.setCursor(new Cursor(Cursor.WAIT_CURSOR));
			CommandEditor.this.getActionMap().get("stop-task").setEnabled(true);
			
			this.setEnabled(false);
			stopped = false;
			
			queryThread = new Thread(this);
			queryThread.start();
		}
		
		public void run()
		{
			String requestString = request.getSelectedText();
			if(requestString == null || requestString.trim().length() == 0)
			{
				// line
				try
				{
					int line = request.getLineOfOffset(request.getCaretPosition());
					
					request.setSelectionStart(request.getLineStartOffset(line));
					request.setSelectionEnd(request.getLineEndOffset(line));
					requestString = request.getSelectedText();
				}
				catch (BadLocationException e)
				{
					Application.println(e,false);
				}
			}
			
			if(requestString == null || requestString.trim().length() == 0)
			{
				// full
				request.setSelectionStart(0);
				request.setSelectionEnd(request.getText().length());
				requestString = request.getSelectedText();
			}
			
			if(requestString != null && requestString.trim().length() > 0)
			{				
				requestString = requestString.trim();
				StringTokenizer st = new StringTokenizer(requestString,";");
				for(int len=0; !stopped && st.hasMoreTokens();)
				{
					String sql = st.nextToken();
					// rimuovere gli a capo da sql!
					
					do
					{
						len += sql.length()+1;
						if(len < requestString.length() && requestString.charAt(len) != '\n' && st.hasMoreTokens())
							sql = sql + ";" + st.nextToken();
						else
							break;
					}
					while(!stopped);
					
					_TaskSource source = new TaskSource(sql);
					
					String keycah = "*** " + source.getHandlerKey() + " ***";
					CommandEditor.this.response.append("\n"+keycah);					
					int offset = CommandEditor.this.response.getDocument().getLength() - keycah.length();
					response.getDocument().setCharacterAttributes(offset,keycah.length(),keycahAttributSet,true);
					CommandEditor.this.response.append("\n" + source.getSyntax() + "\n");
					
					ClientCommandEditor cce = (ClientCommandEditor)Application.window.getClient(ClientCommandEditor.DEFAULT_TITLE);
					new Task(source,CommandEditor.this,cce.getLimitRows()).run();
				}
			}
			setEnabled(true);
			transferFocus();
			
			CommandEditor.this.getActionMap().get("stop-task").setEnabled(false);
			CommandEditor.this.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
		}
	}
	
	private class ActionStopTask extends AbstractAction
	{
		ActionStopTask()
		{
			this.putValue(SMALL_ICON, Application.resources.getIcon(Application.ICON_STOP));
			this.putValue(SHORT_DESCRIPTION, "stop");
			this.setEnabled(false);
		}

		public void actionPerformed(ActionEvent ae)
		{
			stopped = true;
			this.setEnabled(false);
			CommandEditor.this.queryThread = null;
		}
	}
	
//	/////////////////////////////////////////////////////////////////////////////
//	_TaskTarget
//	/////////////////////////////////////////////////////////////////////////////
	public boolean continueRun()
	{
		return queryThread != null;
	}

	public void onTaskFinished(String message,boolean error)
	{
		write(message);
		if(error)
		{
			int offset = response.getDocument().getLength() - message.length();
			response.getDocument().setCharacterAttributes(offset,message.length(),errorAttributSet,true);
		}
		response.append("\n");
	}

	public void write(String text)
	{
		response.append(text);
		try
		{
			int line = response.getLineCount();
			int off = response.getLineStartOffset(line-1);
			
			response.setCaretPosition(off);
		}
		catch (BadLocationException e)
		{
			e.printStackTrace();
		}
	}
	
//	/////////////////////////////////////////////////////////////////////////////
//	TaskSource
//	/////////////////////////////////////////////////////////////////////////////
	private class TaskSource implements _TaskSource
	{
		private String query;
		
		private TaskSource(String query)
		{
			this.query = query;
		}
		
		public String getHandlerKey()
		{
			ClientCommandEditor client = (ClientCommandEditor)Application.window.getClient(ClientCommandEditor.DEFAULT_TITLE);
			return client.getActiveConnection();
		}
		public String getSyntax()
		{
			return query;
		}
	}
}
